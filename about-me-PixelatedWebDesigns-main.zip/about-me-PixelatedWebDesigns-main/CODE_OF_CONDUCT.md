One of the core values of Raritan Valley Community College is to foster an environment of mutual respect, responsibility, and collaboration. The RVCC Code of Student Conduct (Code) establishes expectations of behavior for all RVCC students regardless of enrollment status or campus location. 


By submitting to this repository, the student states that they have neither given nor received unauthorized aid on this assignment.

Additionally, the student will, to the best of their ability, use the README of this repository to link to any resources used to complete the assignment.
